# V3 Action Plan — 行动计划（v3.0.0 新增）

> V3 不能在 MVP Blueprint 结束。必须继续回答："现在第一步做什么？"
> 行动计划按机会类型动态生成，禁止所有项目输出完全相同的步骤。产出 `templates/v3-action-plan-card.md`。

## 1. 机会类型判定

根据目标用户与产品形态自动判定类型（判定时写一句理由）：

| 类型 | 典型特征 | 示例 |
|---|---|---|
| B2B_TOOL 企业工具/服务 | 卖给企业/工作室/店铺/机构，付费方是老板/负责人 | 教培获客内容、门店经营工具 |
| CONSUMER_TOOL 个人工具/App | 卖给个人用户，付费方=使用者 | 简历优化、个人效率 App |
| AI_AGENT AI Agent/自动化 | 核心价值=AI 替用户执行任务/流程 | 自动处理邮件、自动生成周报 |
| LOCAL_SERVICE 本地服务/代做 | 线下或半线下交付，Concierge 属性强 | 代写文案、代做设计 |
| DIGITAL_PRODUCT 内容/数字产品 | 模板/课程/素材/知识资产 | 提示词模板包、行业语料库 |

类型只是起点：用户画像、渠道、交付方式不同时允许混合（如 B2B 的本地服务），并说明混合原因。

## 2. 各类型的默认步骤模板（每步 5 要素）

每步：Step N 目标（Goal）/ 做什么（Do）/ 成功标准（Success）/ 失败转向（Fallback）。

### B2B_TOOL

1. 用户访谈：找 5-10 家目标企业负责人，验证痛点与当前花费。
2. 需求验证：确认付费方、预算与拍产权（付费理由链第⑤环，`demand-validation.md` §5）。
3. 试交付（Concierge）：人工+AI 为 2-3 家免费/低价做出样品结果。
4. 首批付费：报价 → 收首款 → 交付（10/30/50/100 元起步可，`payment-validation.md` §3）。
5. 复购与标准化：收集反馈、固定交付模板、转介绍。
6. 决定：继续 / 修改 / 放弃。

### CONSUMER_TOOL

1. 需求验证：在目标用户聚集处验证痛点与主动寻找行为。
2. Landing Page / 样品：一页讲清价值与价格，看点击与留资。
3. MVP：只做 Must Have（≤3），一周内可上线。
4. 用户测试：10-20 个真实用户试用，收集付费/留存信号。
5. 增长：主渠道 ≤2，内容/社区优先（`monetization-gtm.md` §6.1）。
6. 决定：继续 / 修改 / 放弃。

### AI_AGENT

1. 工作流验证：手工把任务跑通一遍，确认 AI 能稳定完成。
2. AI 能力测试：小样本测质量与错误率，确认人工兜底成本（`project-evaluation.md` §4）。
3. Prototype：半自动原型（L2-L3），真实任务试运行。
4. 用户测试：找早期用户试用，验证"省了多少时间"。
5. 付费与标准化：按结果/订阅收费，固化流程。
6. 决定：继续 / 修改 / 放弃。

### LOCAL_SERVICE

1. 样品交付：为 2-3 家熟悉的潜在客户免费做一份样品（前后对比）。
2. 报价：基于替代成本锚定，先收钱再交付。
3. 第一单：拿到第一笔真实付款（FIRST_PAYMENT，`opportunity-state-machine.md` §3）。
4. 复购：要反馈、要转介绍、要公开案例。
5. 标准化：固定报价与交付模板（REPEATED_DELIVERY→STANDARDIZED）。
6. 决定：继续 / 修改 / 放弃。

### DIGITAL_PRODUCT

1. 内容样品：做 1-3 份代表作品/模板。
2. 销售验证：小范围发售（预售价），看真实购买。
3. 规模化：上平台/内容获客。
4. 迭代：按反馈更新版本。
5. 决定：继续 / 修改 / 放弃。

## 3. 与 Decision 的联动（动态性核心）

| Decision | Action Plan 形态 |
|---|---|
| RECOMMENDED | 执行路径：从"构建/交付"步骤开始，前 1-2 步仍是低成本验证（先拿钱再加大投入） |
| POTENTIAL | 验证优先路径：前两步 = 最小验证实验（不开发产品），看到指定信号才进入后续步骤 |
| NOT_RECOMMENDED | 停止路径：停止三要素 + 重启条件；不生成普通步骤 |

- POTENTIAL 的 Action Plan 第一行必须写："在验证通过前，不开发任何产品。"
- 每一步的成功/失败标准必须量化（几人在几天内做到什么），禁止"继续研究""深入分析"式空话。

## 4. 结尾三件套（所有类型必有）

1. **今天做什么**：1-3 个动词开头、可量化、今天能执行的动作。
2. **第一笔钱路径**：对齐 `payment-validation.md` §3 十步清单与 GTM 阶段 A（`monetization-gtm.md` §6.2）。
3. **状态机对齐**：当前 Opportunity State 与下一步要推进到的状态（`opportunity-state-machine.md` §2-3）。

## 5. 输出

- 使用 `templates/v3-action-plan-card.md`：类型判定 + 步骤表（每步 5 要素）+ 今天做什么 + 第一笔钱路径 + 状态机对齐。


## 6. Evidence-driven Action（v3.1.0 新增，行动层升级）

> V3 的行动由"机会类型 → 模板"驱动；V3.1 必须升级为 **Evidence + Score + Decision + User + Channel + Payment Signal + Unknown + Failure Condition → Evidence-driven Action**。
> 本节规则与 §1-§5 全量兼容：类型模板仍是起点，但每一步都必须用证据实例化，禁止输出泛化步骤。

### 6.1 继承契约（Action 必须继承的字段）

| 字段 | 来源 | 用途 |
|---|---|---|
| target_user | VALIDATE 核心用户 | "找谁" |
| problem / pain | VALIDATE 痛点、P1/P2 证据 | "为什么找他们" |
| distribution_channel | FIND/MONETIZE 渠道证据 或 v3-scoring D1 证据 | "去哪找"（禁止假设不存在的渠道） |
| payment_signal | MONETIZE/Payment 覆盖 | "拿什么 Offer、报多少价" |
| competition_gap | EVALUATE 差异化切入点 | Offer 的差异化话术 |
| decision | v3-decision | 路径形态（执行/验证/停止） |
| unknowns | v3-evidence 看板 Unknown 项 | 每步要验证的假设 |
| hard_gates | v3-hard-gates | 触发条件（如 Payment CEILING → 前两步必须是付费验证） |

### 6.2 每步五要素（Success 与 Fallback 必须具体）

```text
Step N 目标：验证哪个假设 / 推进哪个未知
做什么：动词 + 对象 + 数量 + 渠道（全部来自证据或显式标注）
成功标准：可量化（几人在几天内做到什么）
失败转向：If <量化条件> Then <具体决策>（禁止"继续努力/换个渠道/继续研究"）
```

Fallback 示例（合法）：

```text
If 10 个目标用户中 <2 个有效回应       → 修改 Offer（换引流价/换承诺结果），不开发产品
If 5 个目标用户全部拒绝付费             → 暂停开发，重查 Payment Hypothesis（M1/M2 证据）
```

Fallback 反例（禁止）："不行就继续努力 / 换个渠道试试 / 再深入研究"。

### 6.3 Today 动作格式（Evidence-driven Today）

每个 Today 动作 = 动词 + 对象 + 数量 + 成功标准：

```text
1. 搜索[渠道关键词]，收集 20 条真实用户表达     → 成功标准：≥5 条与假设痛点同类的记录
2. 按[目标用户画像]筛选 5 个高意向对象           → 成功标准：名单可联系
3. 用[当前 Offer]验证 3 个付费意愿               → 成功标准：≥1 个"愿意付费"明确回复
```

禁止："今天：研究市场 / 做竞品分析 / 写 MVP"这类不可执行动作。

### 6.4 与 Decision 的联动（在 §3 基础上细化）

- RECOMMENDED：执行路径，但 Step 1-2 仍是低成本验证（先拿钱再加大投入）。
- POTENTIAL：验证优先路径，**第一行必须写"在验证通过前，不开发任何产品"**；
  前两步 = 针对 `unknowns` 的最小验证实验（优先付费假设）。
- NOT_RECOMMENDED：停止路径（停止三要素），不生成常规步骤。
- 命中 Score Ceiling（v3-hard-gates C1-C4）→ 前两步必须补对应证据（如 Payment 覆盖 < 30 → Step 1 = 获取付费证据）。

### 6.5 输出

- `templates/v3-action-plan-card.md` 新增 `Evidence Basis` 区：列出继承字段（target_user / channel / payment_signal / unknowns / hard_gates），供用户核对每一步都来自证据。
- 步骤表格式不变（每步 5 要素），但所有内容按 6.1-6.3 实例化。
