---
name: fictional-demo
description: Fictional fixture only.
---
Do not install this fixture as a real product.